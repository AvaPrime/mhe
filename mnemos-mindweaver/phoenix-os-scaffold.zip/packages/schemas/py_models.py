from pydantic import BaseModel
class MemoryObject(BaseModel):
    id: str
    content: dict
