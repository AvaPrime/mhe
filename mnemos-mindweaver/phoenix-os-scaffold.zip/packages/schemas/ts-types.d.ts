export type MemoryObject = { id: string; content: Record<string, any> };
