import sys, os, glob, hashlib, time
from qdrant_client import QdrantClient
from qdrant_client.http import models as qmodels
import numpy as np
COLLECTION=os.getenv("QDRANT_COLLECTION","phoenix_memory")
QDRANT_URL=os.getenv("QDRANT_URL","http://localhost:6333")
DIM=int(os.getenv("EMBED_DIM","384"))
def h(t): return hashlib.sha256(t.encode("utf-8")).hexdigest()
def ensure(client):
    names=[c.name for c in client.get_collections().collections]
    if COLLECTION not in names:
        client.recreate_collection(COLLECTION, vectors_config=qmodels.VectorParams(size=DIM, distance=qmodels.Distance.COSINE))
def upsert(client, path):
    txt=open(path,"r",encoding="utf-8",errors="ignore").read()
    vid=h(txt); vec=np.random.randn(DIM).astype("float32").tolist()
    payload={"source":{"type":"local","uri":os.path.abspath(path)},"content":txt,"ts":time.time()}
    client.upsert(COLLECTION, points=[qmodels.PointStruct(id=vid, vector=vec, payload=payload)])
    print("Ingested", path)
def main(folder):
    c=QdrantClient(url=QDRANT_URL); ensure(c)
    for pat in ("**/*.md","**/*.txt"): 
        for f in glob.glob(os.path.join(folder,pat), recursive=True): upsert(c,f)
if __name__=="__main__":
    if len(sys.argv)<2: print("Usage: python ingest_local.py <folder>"); sys.exit(1)
    main(sys.argv[1])
