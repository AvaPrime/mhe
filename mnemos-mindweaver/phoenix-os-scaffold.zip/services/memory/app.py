from fastapi import FastAPI, Query
from pydantic import BaseModel
from typing import List, Dict, Any
from qdrant_client import QdrantClient
from qdrant_client.http import models as qmodels
import numpy as np, os

COLLECTION = os.getenv("QDRANT_COLLECTION","phoenix_memory")
QDRANT_URL = os.getenv("QDRANT_URL","http://localhost:6333")
DIM = int(os.getenv("EMBED_DIM","384"))

app = FastAPI(title="Phoenix Memory Service")
client = QdrantClient(url=QDRANT_URL)

def ensure():
    names = [c.name for c in client.get_collections().collections]
    if COLLECTION not in names:
        client.recreate_collection(COLLECTION, vectors_config=qmodels.VectorParams(size=DIM, distance=qmodels.Distance.COSINE))

@app.on_event("startup")
def startup():
    ensure()

class Hit(BaseModel):
    id: str
    score: float
    payload: Dict[str, Any]

class Recall(BaseModel):
    items: List[Hit]

@app.get("/v1/recall", response_model=Recall)
def recall(q: str = Query(...), top_k: int = 6):
    vec = np.random.randn(DIM).astype("float32").tolist()  # placeholder
    res = client.search(collection_name=COLLECTION, query_vector=vec, limit=top_k, with_payload=True)
    return {"items":[{"id": str(r.id), "score": float(r.score), "payload": r.payload} for r in res]}

@app.get("/health")
def health(): return {"ok": True}
