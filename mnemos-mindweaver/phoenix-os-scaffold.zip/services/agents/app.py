from fastapi import FastAPI
from pydantic import BaseModel
import httpx
from typing import List, Dict, Any
MEMORY_URL="http://localhost:8001"
app=FastAPI(title="Phoenix Agents")
class Ask(BaseModel): query: str; top_k: int=6
class Pack(BaseModel): answer: str; citations: List[Dict[str, Any]]
@app.post("/v1/librarian/ask", response_model=Pack)
async def ask(req: Ask):
    async with httpx.AsyncClient() as cl:
        r=await cl.get(f"{MEMORY_URL}/v1/recall", params={"q": req.query, "top_k": req.top_k}); r.raise_for_status()
        data=r.json()
    items=data.get("items",[])
    parts=[(it.get("payload",{}).get("content") or "")[:160] for it in items]
    answer=" • ".join([p.replace("\n"," ") + ("..." if len(p)==160 else "") for p in parts]) or "No results yet."
    cites=[{"id":it.get("id"),"score":it.get("score"),"uri":it.get("payload",{}).get("source",{}).get("uri")} for it in items]
    return {"answer":answer,"citations":cites}
@app.get("/health")
def health(): return {"ok": True}
