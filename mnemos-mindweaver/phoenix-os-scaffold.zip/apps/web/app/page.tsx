'use client'
import { useState } from 'react'
export default function Home(){
  const [q,setQ]=useState('What do I know about Mnemos?')
  const [ans,setAns]=useState(''); const [cites,setCites]=useState<any[]>([]); const [loading,setLoading]=useState(false)
  async function ask(){
    setLoading(true); setAns(''); setCites([])
    const r=await fetch('http://localhost:8080/v1/ask',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({query:q,top_k:6})})
    const j=await r.json(); setAns(j.answer||''); setCites(j.citations||[]); setLoading(false)
  }
  return (<main>
    <h1 style={{fontSize:28,fontWeight:700}}>Phoenix OS</h1>
    <p>Ask your knowledge base.</p>
    <div style={{display:'flex',gap:8}}>
      <input value={q} onChange={e=>setQ(e.target.value)} style={{flex:1,padding:8,border:'1px solid #ddd',borderRadius:8}}/>
      <button onClick={ask} disabled={loading} style={{padding:'8px 12px',borderRadius:8,border:'1px solid #333'}}>{loading?'Thinking…':'Ask'}</button>
    </div>
    {ans && <div style={{marginTop:12,padding:12,border:'1px solid #eee',borderRadius:8}}><b>Answer</b><div style={{whiteSpace:'pre-wrap'}}>{ans}</div></div>}
    {cites.length>0 && <div style={{marginTop:12}}><b>Citations</b><ul>{cites.map((c,i)=>(<li key={i}><code>{c.id}</code>{c.uri?` — ${c.uri}`:''} (score {Number(c.score).toFixed(3)})</li>))}</ul></div>}
  </main>)
}
