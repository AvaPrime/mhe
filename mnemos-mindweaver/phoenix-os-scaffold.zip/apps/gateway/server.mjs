import Fastify from 'fastify'
const MEMORY_URL=process.env.MEMORY_URL||'http://localhost:8001'
const AGENTS_URL=process.env.AGENTS_URL||'http://localhost:8003'
const app=Fastify({logger:true})
app.get('/v1/recall', async (req)=>{
  const q=req.query.q; const top_k=req.query.top_k||6
  const r=await fetch(`${MEMORY_URL}/v1/recall?q=${encodeURIComponent(q)}&top_k=${top_k}`); return r.json()
})
app.post('/v1/ask', async (req)=>{
  const r=await fetch(`${AGENTS_URL}/v1/librarian/ask`, {method:'POST', headers:{'content-type':'application/json'}, body: JSON.stringify(req.body||{})})
  return r.json()
})
app.get('/health', async ()=>({ok:true}))
app.listen({port:8080, host:'0.0.0.0'}).catch(e=>{console.error(e);process.exit(1)})
