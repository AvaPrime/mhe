# Phoenix OS — Minimal Scaffold

Run infra, start services, and open the web app. See service READMEs for details.
