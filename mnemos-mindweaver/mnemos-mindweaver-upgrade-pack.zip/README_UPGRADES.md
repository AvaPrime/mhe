# Mnemos/MindWeaver Upgrade Pack

This pack adds three things:

1. **Observability**: Prometheus + Grafana stack with a ready-to-import dashboard at `grafana/mnemos-recall-dashboard.json`.
   - Start with: `docker compose -f docker/docker-compose.observability.yml up -d`
   - Grafana: http://localhost:3000 (user: admin, pass: admin)
   - Import the dashboard JSON and set the Prometheus datasource (URL http://prometheus:9090).

2. **HNSW-first Vector Index Config**: Prefer HNSW when available, with graceful fallback.
   - File: `config/vector_index.yaml`
   - Your vector layer should read this and map to backend-specific settings.

3. **Experimental Federated Recall Endpoint**: Query multiple recall nodes and merge results.
   - File: `endpoints/federated_recall.py`
   - Mount in FastAPI: 
     ```python
     from endpoints.federated_recall import router as federated_router
     app.include_router(federated_router, prefix="/v1")
     ```
   - Configure peers: `FEDERATED_PEERS="http://node1:8000,http://node2:8000"`

4. **Prometheus Scrape Config**: Minimal scrape config for recall and a vector store exporter.
   - File: `prometheus/prometheus.yml`
   - Update target hostnames/ports to match your deployment.

> Notes:
> - The dashboards assume you expose Prometheus metrics for `recall_requests_total`, `recall_latency_seconds_*`, and `vector_store_index_size`. Adjust metrics names to your actual exporter if different.
> - The federated endpoint is experimental and uses simple score normalization; replace with RRF or Borda if you need stronger rank fusion.
