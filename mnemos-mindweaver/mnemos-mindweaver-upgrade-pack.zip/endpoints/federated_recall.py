"""
Experimental Federated Recall Endpoint
--------------------------------------
Aggregates results across multiple Mnemos/MindWeaver nodes.
Usage:
  - Mount this router in your FastAPI app:
        from endpoints.federated_recall import router as federated_router
        app.include_router(federated_router, prefix="/v1")
  - Configure peers via FEDERATED_PEERS env var: "http://node1:8000,http://node2:8000"
Metrics:
  - Exposes simple Prometheus counters for aggregate requests and failures.
"""
import os
import asyncio
from typing import List, Dict, Any
from fastapi import APIRouter, HTTPException, Body
import httpx
from prometheus_client import Counter

router = APIRouter()
REQS = Counter("federated_recall_requests_total", "Federated recall requests")
FAILS = Counter("federated_recall_failures_total", "Federated recall failures")

def get_peers() -> List[str]:
    raw = os.getenv("FEDERATED_PEERS", "").strip()
    peers = [p.strip() for p in raw.split(",") if p.strip()]
    return peers

async def query_peer(client: httpx.AsyncClient, base: str, payload: Dict[str, Any]) -> Dict[str, Any]:
    url = f"{base.rstrip('/')}/v1/recall"
    try:
        r = await client.post(url, json=payload, timeout=20)
        r.raise_for_status()
        data = r.json()
        return {"peer": base, "ok": True, "data": data}
    except Exception as e:
        return {"peer": base, "ok": False, "error": str(e)}

def merge_results(results: List[Dict[str, Any]], top_k: int = 10) -> Dict[str, Any]:
    # Simple rank fusion: interleave by normalized score; assumes each peer returns items with "score"
    items = []
    for res in results:
        if res.get("ok"):
            for it in res["data"].get("items", []):
                it["_peer"] = res["peer"]
                items.append(it)
    # Normalize by per-peer max
    by_peer = {}
    for it in items:
        by_peer.setdefault(it["_peer"], []).append(it)
    for peer, arr in by_peer.items():
        max_s = max((x.get("score", 0.0) for x in arr), default=1.0) or 1.0
        for x in arr:
            x["_nscore"] = x.get("score", 0.0) / max_s
    items.sort(key=lambda x: x.get("_nscore", 0.0), reverse=True)
    return {"items": items[:top_k], "sources": list({it["_peer"] for it in items})}

@router.post("/federated_recall")
async def federated_recall(
    query: Dict[str, Any] = Body(..., description="Payload compatible with /v1/recall"),
    top_k: int = 10
):
    REQS.inc()
    peers = get_peers()
    if not peers:
        FAILS.inc()
        raise HTTPException(status_code=400, detail="No peers configured. Set FEDERATED_PEERS.")
    async with httpx.AsyncClient() as client:
        tasks = [query_peer(client, p, query) for p in peers]
        results = await asyncio.gather(*tasks)
    if not any(r.get("ok") for r in results):
        FAILS.inc()
        raise HTTPException(status_code=502, detail={"results": results})
    merged = merge_results(results, top_k=top_k)
    return {"query": query, "merged": merged, "raw": results}
